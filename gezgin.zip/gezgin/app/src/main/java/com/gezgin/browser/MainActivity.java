package com.gezgin.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;

import java.util.*;

public class MainActivity extends Activity {
    static final String HOME = "file:///android_asset/home.html";
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

    final List<WebView> tabs = new ArrayList<>();
    final Set<WebView> desktop = new HashSet<>();
    int cur = -1;
    FrameLayout container, fullscreen;
    EditText urlBar;
    ProgressBar progress;
    Button btnTabs;
    View customView;
    WebChromeClient.CustomViewCallback customCb;
    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("gezgin", MODE_PRIVATE);
        container = findViewById(R.id.container);
        fullscreen = findViewById(R.id.fullscreen);
        urlBar = findViewById(R.id.urlBar);
        progress = findViewById(R.id.progress);
        btnTabs = findViewById(R.id.btnTabs);
        if (Build.VERSION.SDK_INT < 29) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
        }
        urlBar.setOnEditorActionListener((v, id, e) -> {
            if (id == EditorInfo.IME_ACTION_GO || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                go(urlBar.getText().toString());
                return true;
            }
            return false;
        });
        findViewById(R.id.btnBack).setOnClickListener(v -> { if (w() != null && w().canGoBack()) w().goBack(); });
        findViewById(R.id.btnFwd).setOnClickListener(v -> { if (w() != null && w().canGoForward()) w().goForward(); });
        findViewById(R.id.btnHome).setOnClickListener(v -> w().loadUrl(HOME));
        btnTabs.setOnClickListener(v -> showTabs());
        findViewById(R.id.btnMenu).setOnClickListener(this::showMenu);
        Uri d = getIntent().getData();
        newTab(d != null ? d.toString() : HOME);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i.getData() != null) newTab(i.getData().toString());
    }

    WebView w() { return cur >= 0 && cur < tabs.size() ? tabs.get(cur) : null; }

    String norm(String t) {
        t = t.trim();
        if (t.isEmpty()) return HOME;
        if (t.matches("(?i)^(https?|file)://.*")) return t;
        if (!t.contains(" ") && t.matches("^[\\w-]+(\\.[\\w-]+)+(/.*)?$")) return "https://" + t;
        return "https://www.google.com/search?q=" + Uri.encode(t);
    }

    void go(String t) {
        w().loadUrl(norm(t));
        urlBar.clearFocus();
        InputMethodManager im = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    void newTab(String url) {
        final WebView wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true);
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http") || u.startsWith("file:")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) { }
                return true;
            }
            @Override
            public void onPageStarted(WebView v, String u, Bitmap f) { if (v == w()) showUrl(u); }
            @Override
            public void onPageFinished(WebView v, String u) { if (v == w()) showUrl(u); }
        });
        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (v != w()) return;
                progress.setProgress(p);
                progress.setVisibility(p < 100 ? View.VISIBLE : View.INVISIBLE);
            }
            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                customView = v; customCb = cb;
                fullscreen.addView(v);
                fullscreen.setVisibility(View.VISIBLE);
                getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }
            @Override
            public void onHideCustomView() { hideCustom(); }
        });
        wv.setDownloadListener((u, ua, cd, mime, len) -> {
            try {
                String name = URLUtil.guessFileName(u, cd, mime);
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(u));
                r.setMimeType(mime);
                r.addRequestHeader("User-Agent", ua);
                String ck = CookieManager.getInstance().getCookie(u);
                if (ck != null) r.addRequestHeader("Cookie", ck);
                r.setTitle(name);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "İndiriliyor: " + name, Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "İndirme başlatılamadı", Toast.LENGTH_LONG).show();
            }
        });
        tabs.add(wv);
        switchTo(tabs.size() - 1);
        wv.loadUrl(url);
    }

    void switchTo(int i) {
        container.removeAllViews();
        cur = i;
        container.addView(w(), new ViewGroup.LayoutParams(-1, -1));
        showUrl(w().getUrl());
        progress.setVisibility(View.INVISIBLE);
        btnTabs.setText(String.valueOf(tabs.size()));
    }

    void closeTab(int i) {
        WebView x = tabs.remove(i);
        desktop.remove(x);
        x.destroy();
        if (tabs.isEmpty()) { newTab(HOME); return; }
        switchTo(Math.min(i, tabs.size() - 1));
    }

    void showUrl(String u) {
        if (u == null || u.startsWith("file:///android_asset")) urlBar.setText("");
        else urlBar.setText(u);
    }

    void showTabs() {
        String[] names = new String[tabs.size()];
        for (int i = 0; i < names.length; i++) {
            String t = tabs.get(i).getTitle();
            names[i] = (i == cur ? "● " : "") + (t == null || t.isEmpty() ? "Yeni sekme" : t);
        }
        new AlertDialog.Builder(this).setTitle("Sekmeler")
            .setItems(names, (d, i) -> switchTo(i))
            .setPositiveButton("＋ Yeni sekme", (d, i) -> newTab(HOME))
            .setNeutralButton("Bu sekmeyi kapat", (d, i) -> closeTab(cur))
            .show();
    }

    void showMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Yenile");
        m.getMenu().add(0, 2, 1, desktop.contains(w()) ? "Mobil site" : "Masaüstü sitesi");
        m.getMenu().add(0, 3, 2, "Favorilere ekle");
        m.getMenu().add(0, 4, 3, "Favoriler");
        m.getMenu().add(0, 5, 4, "İndirilenler");
        m.getMenu().add(0, 6, 5, "Paylaş");
        m.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: w().reload(); break;
                case 2: toggleDesktop(); break;
                case 3: addFav(); break;
                case 4: showFavs(); break;
                case 5: startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); break;
                case 6:
                    Intent s = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, w().getUrl());
                    startActivity(Intent.createChooser(s, "Paylaş"));
                    break;
            }
            return true;
        });
        m.show();
    }

    void toggleDesktop() {
        WebView x = w();
        if (desktop.remove(x)) x.getSettings().setUserAgentString(null);
        else { desktop.add(x); x.getSettings().setUserAgentString(DESKTOP_UA); }
        x.reload();
    }

    void addFav() {
        String u = w().getUrl();
        if (u == null || u.startsWith("file:")) return;
        Set<String> f = new LinkedHashSet<>(prefs.getStringSet("fav", new LinkedHashSet<>()));
        f.add(u);
        prefs.edit().putStringSet("fav", f).apply();
        Toast.makeText(this, "Favorilere eklendi", Toast.LENGTH_SHORT).show();
    }

    void showFavs() {
        final List<String> f = new ArrayList<>(prefs.getStringSet("fav", new LinkedHashSet<>()));
        if (f.isEmpty()) { Toast.makeText(this, "Favori yok", Toast.LENGTH_SHORT).show(); return; }
        new AlertDialog.Builder(this).setTitle("Favoriler")
            .setItems(f.toArray(new String[0]), (d, i) -> w().loadUrl(f.get(i)))
            .setNeutralButton("Tümünü sil", (d, i) -> prefs.edit().remove("fav").apply())
            .show();
    }

    void hideCustom() {
        if (customView == null) return;
        fullscreen.removeView(customView);
        fullscreen.setVisibility(View.GONE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        if (customCb != null) customCb.onCustomViewHidden();
        customView = null;
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (w() != null && w().canGoBack()) { w().goBack(); return; }
        if (tabs.size() > 1) { closeTab(cur); return; }
        super.onBackPressed();
    }

    @Override protected void onPause() { super.onPause(); CookieManager.getInstance().flush(); }
}
