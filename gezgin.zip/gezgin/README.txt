GEZGİN TARAYICI — KURULUM (Türkçe)

1) Bilgisayarına Android Studio kur (developer.android.com/studio).
2) Bu klasörü (Gezgin) zip'ten çıkar.
3) Android Studio > File > Open > Gezgin klasörünü seç.
4) İlk açılışta "Gradle sync" otomatik başlar (internet gerekir, birkaç dakika sürebilir).
   "Update Gradle/plugin?" diye sorarsa "Update" de.
5) Telefonda: Ayarlar > Telefon hakkında > Yapı numarasına 7 kez dokun > Geliştirici seçenekleri > USB hata ayıklama AÇIK.
6) Telefonu USB ile bağla, Android Studio'da yeşil ▶ (Run) tuşuna bas.

APK dosyası istersen: Build > Build Bundle(s)/APK(s) > Build APK(s).
Not: Android Studio telefonda çalışmaz, bilgisayar gerekir.
